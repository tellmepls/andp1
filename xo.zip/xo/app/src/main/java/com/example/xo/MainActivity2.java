package com.example.xo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ActivityChooserView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {
    String w = "";
    Button b1;
    Button b2;
    Button b3;
    Button b4;
    Button b5;
    Button b6;
    Button b7;
    Button b8;
    Button b9;
    boolean k = true;

    @Override
    protected void  onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);

    }
    public void cl(View x) {
        Intent p = new Intent(MainActivity2.this, MainActivity3.class);

        switch (x.getId()) {
            case R.id.b1: {
                if (k) {
                    b1.setText("X");
                    k = false;
                } else {
                    b1.setText("0");
                    k = true;
                }
                b1.setEnabled(false);

                break;
            }
            case R.id.b2: {
                if (k) {
                    b2.setText("X");
                    k = false;
                } else {
                    b2.setText("0");
                    k = true;
                }
                b2.setEnabled(false);

                break;
            }
            case R.id.b3: {
                if (k) {
                    b3.setText("X");
                    k = false;
                } else {
                    b3.setText("0");
                    k = true;
                }
                b3.setEnabled(false);

                break;
            }
            case R.id.b4: {
                if (k) {
                    b4.setText("X");
                    k = false;
                } else {
                    b4.setText("0");
                    k = true;
                }
                b4.setEnabled(false);

                break;
            }
            case R.id.b5: {
                if (k) {
                    b5.setText("X");
                    k = false;
                } else {
                    b5.setText("0");
                    k = true;
                }
                b5.setEnabled(false);

                break;
            }
            case R.id.b6: {
                if (k) {
                    b6.setText("X");
                    k = false;
                } else {
                    b6.setText("0");
                    k = true;
                }
                b6.setEnabled(false);

                break;
            }
            case R.id.b7: {
                if (k) {
                    b7.setText("X");
                    k = false;
                } else {
                    b7.setText("0");
                    k = true;
                }
                b7.setEnabled(false);

                break;
            }
            case R.id.b8: {
                if (k) {
                    b8.setText("X");
                    k = false;
                } else {
                    b8.setText("0");
                    k = true;
                }
                b8.setEnabled(false);

                break;
            }
            case R.id.b9: {
                if (k) {
                    b9.setText("X");
                    k = false;
                } else {
                    b9.setText("0");
                    k = true;
                }
                b9.setEnabled(false);
                break;
            }

        }
        if (b1.getText() == b2.getText() && b2.getText() == b3.getText() && b3.getText() != "") {

            w = b1.getText().toString();
            p.putExtra("opred", w);
            startActivity(p);
        } else if (b1.getText() == b5.getText() && b5.getText() == b9.getText() && b9.getText() != "") {
            w = b1.getText().toString();
            p.putExtra("opred", w);
            startActivity(p);
        } else if (b1.getText() == b4.getText() && b4.getText() == b7.getText() && b7.getText() != "") {
            w = b1.getText().toString();
            p.putExtra("opred", w);
            startActivity(p);
        } else if (b2.getText() == b5.getText() && b5.getText() == b8.getText() && b8.getText() != "") {
            w = b2.getText().toString();
            p.putExtra("opred", w);
            startActivity(p);
        } else if (b3.getText() == b6.getText() && b6.getText() == b9.getText() && b9.getText() != "") {
            w = b3.getText().toString();
            p.putExtra("opred", w);
            startActivity(p);
        } else if (b3.getText() == b5.getText() && b5.getText() == b7.getText() && b7.getText() != "") {
            w = b3.getText().toString();
            p.putExtra("opred", w);
            startActivity(p);
        } else if (b4.getText() == b5.getText() && b5.getText() == b6.getText() && b6.getText() != "") {
            w = b4.getText().toString();
            p.putExtra("opred", w);
            startActivity(p);
        } else if (b7.getText() == b8.getText() && b8.getText() == b9.getText() && b9.getText() != "") {
            w = b7.getText().toString();
            p.putExtra("opred", w);
            startActivity(p);
        } else if (!(b1.getText().toString().isEmpty() || b2.getText().toString().isEmpty() || b3.getText().toString().isEmpty() || b4.getText().toString().isEmpty() || b5.getText().toString().isEmpty() || b6.getText().toString().isEmpty() || b7.getText().toString().isEmpty() || b8.getText().toString().isEmpty() || b9.getText().toString().isEmpty())) {
            w = "Nichya";
            p.putExtra("opred", w);
            startActivity(p);
        }
    }
        public void clear()
        {
            b1.setText("");
            b2.setText("");
            b3.setText("");
            b4.setText("");
            b5.setText("");
            b6.setText("");
            b7.setText("");
            b8.setText("");
            b9.setText("");
        }
    }